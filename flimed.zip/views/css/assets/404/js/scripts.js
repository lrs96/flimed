/*
 ----------------------------------------------------------------------
 Preloader
 ----------------------------------------------------------------------
 */
$(window).on("load", function(e) {

    "use strict";

    $(".loader").delay(400).fadeOut();
    $(".animationload").delay(400).fadeOut("fast");

});
