<?php include('includes/header-medico.php'); ?>

<section class="box__panel">
	<div class="container">
		<div class="row mosaic">
			<div class="col-md-12">
				<div class="mosaic-item cards">

			</div>
			</div>
			</div>
			</div>
</section>
<?php include('includes/footer.php'); ?>
