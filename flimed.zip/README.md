## Conexão Saúde

- Repository for Conexão Saúde
- Documentation: https://drive.google.com/open?id=12_aR_1vVb26U6qNZPif12mHB0KCYyN5k

## Licensing

- Copyright 2019 Conexão Saúde (https://conexaos.com)
- Licensed under restrict/private use (https://github.com/souzajr/conexaosaude/blob/master/LICENSE.md)

## Credits

- Developed by PurpleTech (https://purpletech.com.br)