Private and Restricted Use 

Copyright (c) 2019 Conexão Saúde


The use of this repository and software is exclusive to its owners.
It is prohibited to use, disclose and / or modify all content.